﻿'use strict';
composerDirectives.directive("csAvaliableTemplatePane", function () {
    return {
        restrict: "E",
        replace: true,
        scope: {
            scopeName: "=",
            contentTypeList: "=",
            contentTypeList1: "=",
            fieldList: "=",
            dropZone: "="
        },
        templateUrl: "/Modules/avaliableTemplates/avaliabletemplate.html",
        controller: ["$scope", "$http", "$compile", "composerService", "$rootScope", "$injector",
            function ($scope, $http, $compile, composerService, $rootScope, $injector) {
                $scope.bodyValue;
                $scope.dataLoaded = false;
                $scope.notOnKeyUp;
                $scope.notOnKeyUp = $scope.notOnKeyUp == undefined ? false : $scope.notOnKeyUp;
                $scope.refreshTemplateList = function () {
                    blockComposerUI();
                    $scope.templateList = [];
                    $http({
                        url: "/api/TemplateApi/GetLayoutTemplates",
                        method: "GET"
                    })
                        .then(function (response) {
                            unblockComposerUI();
                            $scope.dataLoaded = true;
                            for (var i = 0; i < response.data.length; i++) {
                                var temp = [];
                                var json = JSON.parse(JSON.stringify(response.data[i]));
                                temp.TemplateName = json.TemplateName;
                                temp.ComposerLayoutContent = json.ComposerLayoutContent;
                                temp.AuthoringContent = json.AuthoringContent;                                
                                temp.CollectionId = json.CollectionId;
                                temp.StylesheetFileName = json.StylesheetFileName;
                                temp.TemplateTypeName = json.TemplateTypeName;
                                temp.Id = json.Id;
                                temp.isCheckedOutByCurrentUser = json.isCheckedOutByCurrentUser;
                                temp.isCheckedOutByOtherUser = json.isCheckedOutByOtherUser;
                                temp.CheckedoutBy = json.CheckedoutBy;
                                temp.Modified = json.Modified;
                                $scope.templateList.push(temp);
                                $scope.templateList1 = angular.copy($scope.templateList);


                                var allLayoutTemplates = JSON.parse(JSON.stringify(response.data));
                                $scope.allLayoutTemplates = allLayoutTemplates;
                                composerService.saveAllLayoutTemplates(allLayoutTemplates);
                            }
                            $rootScope.$broadcast("getTemplateNamesToProperties", $scope.templateList);
                        },
                        function (data) {
                            var msg = data.error;
                        });
                };
                $scope.refreshTemplateList();
                composerService.onTemplateSaved($scope, $scope.refreshTemplateList);

                $scope.showTemplate = function (templateName, isCheckedOutByCurrentUser, isCheckedOutByOtherUser, jsonContent, templateContentType, template) {
                    var htmlContent = JSON.parse(jsonContent);
                    var authoringContent = template.AuthoringLayoutContent;
                    var stylesheetfilename = "";
                    $rootScope.selectedTemplate = template;
                   // template.StylesheetFileName = template.StylesheetFileName.replace('.css', "");
                    if (template.StylesheetFileName.indexOf(","))
                    {
                        var arrayFiles = template.StylesheetFileName.split(',');
                        for (var file in arrayFiles) {
                            
                            arrayFiles[file]= arrayFiles[file].replace('.css', "");
                           if (stylesheetfilename === "")
                               stylesheetfilename = arrayFiles[file];
                            else
                               stylesheetfilename += "," + arrayFiles[file];
                        }
                    }
                    $('#StylesheetFile').val(stylesheetfilename);
                    $rootScope.selectedStyles = $('#StylesheetFile').val();
                    $('#SelectedFieldTitle').css('visibility', 'hidden');
                    $('#DisplayProperties').css('visibility', 'hidden');
                    $rootScope.isCheckedOutByCurrentUser = false;
                    $rootScope.isCheckedOutByOtherUser = false;
                    if (isCheckedOutByCurrentUser) {
                        $rootScope.isCheckedOutByCurrentUser = true;
                    }
                    else {
                        $rootScope.isCheckedOutByCurrentUser = false;
                    }

                    if (isCheckedOutByOtherUser) {
                        $rootScope.isCheckedOutByOtherUser = true;
                    }
                    else {
                        $rootScope.isCheckedOutByOtherUser = false;
                    }

                    $rootScope.TemplateMode = "edit";                   
                    getContentTemplates();
                    composerService.templateLoad($scope.scopeName, templateName);
                    $rootScope.contentTypeList1 = $scope.contentTypeList1;
                    var splitArr = templateContentType.split(",");
                    if (splitArr.length > 0) {
                        var selectedContentTypes = [];
                        angular.forEach(splitArr, function (typeName) {
                            var type = $.grep($scope.contentTypeList1, function (e) { return e.Name !=undefined && e.Name.toLowerCase() == typeName.toLowerCase(); });
                            selectedContentTypes.push(type[0]);
                        });

                        composerService.contentTypeSelected($scope.scopeName, selectedContentTypes);
                        //for unchecking any checked ContentTypes as we selected layout
                        angular.forEach($('#ContentTypeList input'), function (value) {
                            var type = $.grep(selectedContentTypes, function (e) { return e.Key == $(value)[0].id; });
                            if (type.length > 0) {
                                if (!$(value).prop('checked')) {
                                    setTimeout(function () {

                                        $(value).trigger('click').attr('checked', 'checked');
                                    }, 200);
                                }
                            }
                            else if ($(value).prop('checked')) {
                                setTimeout(function () {
                                    $(value).trigger('click').attr('checked', false);
                                }, 200);

                            }

                        });
                    }


                    $('#CreateButton').css('visibility', 'visible');
                    $('#CheckInButton').css('visibility', 'visible');
                    $('#CheckOutButton').css('visibility', 'visible');
                    $('#DiscardButton').css('visibility', 'visible');
                    $('#TemplateNameInput').val(templateName);
                    $scope.$parent.models = {
                        selected: null,
                        dropzones: { 0: htmlContent[0] }
                    };
                };


                //Get Rendering templates from the Rendering Templates collection in the Elastic
                 var getContentTemplates = function () {
                    $scope.contentTemplateList = [];
                    $scope.fieldType = $rootScope.csName;
                    var apiRequest = {
                        SearchText: " ",
                        SearchableFields: []
                    }
                    $http({
                        url: "/api/TemplateApi/GetRenderingTemplates",
                        method: "POST",
                        data: apiRequest
                    }).then(function (response) {
                        for (var i = 0; i < response.data.length; i++) {
                            var json = JSON.parse(JSON.stringify(response.data[i]));
                            var allRenderingTemplates = JSON.parse(JSON.stringify(response.data));
                            $scope.allRenderingTemplates = allRenderingTemplates;
                            composerService.saveAllRenderingTemplates(allRenderingTemplates);
                            if (json.TemplateType == 'Composite') {
                                var templateNames = [];
                                templateNames.push(json.TemplateTypeName);
                                var splitTemplateName = templateNames[0].split(",");
                                var SearchTemplateName = splitTemplateName.indexOf($scope.fieldName);
                                if (SearchTemplateName > -1) {
                                    $scope.contentTemplateList.push(json);
                                }
                                if (json.TemplateName == "Default-" + $scope.fieldType) {
                                    $scope.contentTemplateList.push(json);
                                }
                            }
                            else {
                                if (json.TemplateType == $scope.fieldType) {
                                    $scope.contentTemplateList.push(json);
                                }
                            }
                        }
                    });
                };

                var deleteTemplate = function (fileName, okFlag) {
                    blockComposerUI();
                    var layoutTemplates = [];
                    layoutTemplates = composerService.getAllLayoutTemplates();
                    angular.forEach(layoutTemplates, function (value, key) {
                        if (value.TemplateName == $scope.removedFileName) {
                            if (okFlag) {
                                var item = {
                                    CollectionId: value.CollectionId,
                                    Id: value.Id,
                                    Action: 'Delete'
                                };
                                var apiRequest = {
                                    Item: item

                                };
                                $http({
                                    url: "/api/TemplateApi/TemplateOperations",
                                    method: "POST",
                                    data: apiRequest
                                })
                                    .then(function (response) {
                                        if (response.data.success == "True") {
                                            unblockComposerUI();
                                            $scope.refreshTemplateList();
                                            notifySuccess(response.data.successMessage);
                                            if ($('#TemplateNameInput')[0].value == $scope.removedFileName) {
                                                $scope.dropZone = { 0: [] };
                                                $("#DisplayProperties").css('visibility', 'hidden');
                                                $('#TemplateNameInput').val('');
                                                angular.forEach($('#ContentTypeList input'), function (value, key) {
                                                    if ($(value).prop('checked')) {
                                                        setTimeout(function () {
                                                            $(value).trigger('click');
                                                        }, 200);
                                                    }
                                                })
                                                composerService.contentTypeSelected($scope.scopeName, []);
                                            }
                                        }
                                        else {
                                            unblockComposerUI();
                                            notifyError(response.data.errorMessage);
                                        }
                                    });
                            }
                        }
                    });
                }

                $scope.detectEnterKey = function ($event) {
                    if ($event.keyCode === 13)
                        $scope.searchLayout();
                }

                $scope.keyUpEvent = function (event) {
                    //this code change to stop search on key up for profile containers
                    if ($scope.notOnKeyUp === false)
                        $scope.searchLayout();
                    if (event.keyCode === 13) {
                        $scope.searchLayout();
                    }
                }


                $scope.searchLayout = function () {
                    $scope.blnNoRecordsFound = false;
                    if ($scope.templateList == "" || $scope.templateList[0].length == 0) {
                        $scope.templateList = composerService.getAllLayoutTemplates();
                    }
                    if ($scope.searchText != "" && $scope.searchText != undefined) {
                        if ($scope.templateList1 === undefined)
                            $scope.templateList1 = $scope.templateList;
                        if ($scope.templateList1.length > $scope.templateList.length) {
                            $scope.templateList = [];
                            $scope.templateList = $scope.templateList1;
                        }

                        var templateList2 = [];
                        angular.forEach($scope.templateList, function (type) {
                            if (type.TemplateName != undefined && type.TemplateName.toLowerCase().indexOf($scope.searchText.toLowerCase()) > -1) {
                                templateList2.push(type);
                            }
                        });
                        if (templateList2.length > 0) {
                            $scope.templateList1 = $scope.templateList;
                            $scope.templateList = templateList2;
                        }
                        else {
                            $scope.blnNoRecordsFound = true;
                            $scope.templateList = "";
                        }
                    }
                    if ($scope.searchText === "" && $scope.templateList.length < $scope.templateList1.length) {
                        $scope.templateList = $scope.templateList1;
                    }
                }

                $scope.deleteTemplateClicked = function (e, name, content, isCheckedOutByCurrentUser, isCheckedOutByOtherUser, CheckedoutBy) {
                    if (isCheckedOutByCurrentUser) {
                        alert('Layout is checked out to you');
                        return;
                    }

                    if (isCheckedOutByOtherUser) {
                        alert('Layout is checked out by ' + CheckedoutBy);
                        return;
                    }
                    $scope.removedFileName = name;
                    $scope.eventClicked = e;
                    $scope.deletehtmlContent = content;
                    csConfirmDialog("Are you sure you want to delete the item(s) : " + name + " ?", deleteTemplate, {});

                };

                function decodeHtml(html) {
                    var txt = document.createElement("textarea");
                    txt.innerHTML = html;
                    return txt.value;
                }
            }]
    }
});